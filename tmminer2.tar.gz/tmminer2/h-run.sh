#!/usr/bin/env bash

. h-manifest.conf

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf
echo "> install dependencies"
$SCRIPT_DIR/install.sh
echo "> dependencies installed"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

$LINE
echo -e "${GREEN}> Starting custom miner:${WHITE}"
MY_PID=$$

config_line=$(cat customconf.conf 2>/dev/null)

tr=$(nproc --ignore=3)
T=3
L=2560

if [[ -n "$config_line" ]]; then
    set -- $config_line

    while [[ $# -gt 0 ]]; do
        case $1 in
            -t_lim)
                tr=$(nproc --ignore="$2")
                shift 2
                ;;
            -t)
                T="$2"
                shift 2
                ;;
            -ram_lim)
                L=$(( "$2" * 1024))
                shift 2
                ;;
            *)
                shift
                ;;
        esac
    done
fi

n=$(( $tr / $T ))
sleep 5
R=$(( ( $(free -m | awk 'NR==2{print $7}') - $L ) / $n ))
for ((i = 1; i <= n; i++)); do
  screenName="cpu$i"
  batch="java -Xms${R}M -Xmx${R}M -XX:+UseG1GC -XX:+AlwaysPreTouch -jar ./cpu.jar $(< $CUSTOM_CONFIG_FILENAME) -t $T"
  fullBatch=$(cat <<EOF
(
  ( while kill -0 $MY_PID 2>/dev/null; do sleep 5; done
    echo "java$i: parent died, shutting down miner..."
    kill \$\$ ) &

  while true; do $batch 2>&1; done
)
EOF
)

  echo "$batch"

  $SCRIPT_DIR/screen-kill $screenName
  screen -dmS "$screenName" bash -c "$fullBatch"
done

read -r -a args < "$CUSTOM_USER_CONFIG_FILENAME"

echo "Args: ${args[@]}"

unbuffer "./$CUSTOM_NAME" "${args[@]}"
