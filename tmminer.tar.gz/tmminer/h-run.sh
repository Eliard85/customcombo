#!/usr/bin/env bash

. h-manifest.conf

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
. $SCRIPT_DIR/h-manifest.conf
echo "> install dependencies"
$SCRIPT_DIR/install.sh
echo "> dependencies installed"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1

$LINE
echo -e "${GREEN}> Starting custom miner:${WHITE}"
MY_PID=$$
t=`cat $THREADS`
n=$(( $(nproc --ignore=1) / $t ))
for ((i = 1; i <= n; i++)); do
  screenName="cpu$i"
  batch="java -jar -Xmx$(( ( $(free -m | awk 'NR==2{print $4}') - 512 ) / $n ))M ./cpu.jar $(< $CUSTOM_CONFIG_FILENAME)"
  fullBatch=$(cat <<EOF
(
  ( while kill -0 $MY_PID 2>/dev/null; do sleep 5; done
    echo "java$i: parent died, shutting down miner..."
    kill \$\$ ) &

  while true; do $batch 2>&1; done
)
EOF
)

  echo "$batch"

  $SCRIPT_DIR/screen-kill $screenName
  screen -dmS "$screenName" bash -c "$fullBatch"
done

conf=`cat $MINER_CONFIG_FILENAME`

echo $conf

if [[ $conf=~';' ]]; then
    conf=`echo $conf | tr -d '\'`
fi

eval "unbuffer ./$CUSTOM_NAME ${conf//;/'\;'}"
