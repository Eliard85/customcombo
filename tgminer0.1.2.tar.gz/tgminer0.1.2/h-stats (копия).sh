#!/usr/bin/env bash

#######################
# MAIN script body
#######################

. /hive/miners/custom/$CUSTOM_NAME/h-manifest.conf
stats_raw=`cat $CUSTOM_LOG_BASENAME.log | grep -w "speed" | tail -n 1`
#echo $stats_raw

#Calculate miner log freshness

maxDelay=120
time_now=`date +%s`
time_rep=`echo $stats_raw | awk '{print $1}' | sed 's/\.[0-9]\+Z$/Z/' | xargs -I{} date -d {} +%s`
diffTime=`echo $((time_now-time_rep)) | tr -d '-'`

if [ "$diffTime" -lt "$maxDelay" ]; then

        #GPU Status
        gpu_stats=$(< $GPU_STATS_JSON)

        readarray -t gpu_stats < <( jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
        busids=(${gpu_stats[0]})
        brands=(${gpu_stats[1]})
        temps=(${gpu_stats[2]})
        fans=(${gpu_stats[3]})
        gpu_count=${#busids[@]}

        hash_arr=()
        busid_arr=()
        fan_arr=()
        temp_arr=()
        lines=()

        if [ $(gpu-detect NVIDIA) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect NVIDIA)
                BRAND_MINER="nvidia"
        elif [ $(gpu-detect AMD) -gt 0 ]; then
                brand_gpu_count=$(gpu-detect AMD)
                BRAND_MINER="amd"
        fi

        for(( i=0; i < gpu_count; i++ )); do
                [[ "${brands[i]}" != $BRAND_MINER ]] && continue
                [[ "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]]
                busid_arr+=($((16#${BASH_REMATCH[1]})))
                temp_arr+=(${temps[i]})
                fan_arr+=(${fans[i]})
                gpu_raw=`cat $CUSTOM_LOG_BASENAME.log | grep -w "Card-"$i | tail -n 1 `
                hashrate=`echo $gpu_raw | awk '{print $5}'`
                hash_arr+=($hashrate)
        done

	total_hashrate=$(echo "${hash_arr[@]}" | awk '{sum=0; for(i=1;i<=NF;i++) sum+=$i; print sum}')

        hash_json=`printf '%s\n' "${hash_arr[@]}" | jq -cs '.'`
        bus_numbers=`printf '%s\n' "${busid_arr[@]}"  | jq -cs '.'`
        fan_json=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
        temp_json=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

        uptime=$(( `date +%s` - `stat -c %Y $CUSTOM_USER_CONFIG_FILENAME` ))


        #Compile stats/ps
        stats=$(jq -nc \
                --argjson hs "$hash_json"\
                --arg ver "$CUSTOM_VERSION" \
                --arg ths "$total_hashrate" \
                --argjson bus_numbers "$bus_numbers" \
                --argjson fan "$fan_json" \
                --argjson temp "$temp_json" \
                --arg uptime "$uptime" \
                '{ hs: $hs, hs_units: "p/s", algo : "SNARK", ver:$ver , $uptime, $bus_numbers, $temp, $fan}')
        ps=$total_hashrate
else
  ps=0
  stats="null"
fi

echo Debug info:
echo Log file : $CUSTOM_LOG_BASENAME.log
echo Time since last log entry : $diffTime
echo Raw stats : $stats_raw
echo PS : $ps
echo Output : $stats

[[ -z $ps ]] && ps=0
[[ -z $stats ]] && stats="null"
