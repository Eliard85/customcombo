#!/usr/bin/env bash
# НИЧЕГО НЕ ПЕЧАТАТЬ. НЕ ДЕЛАТЬ exit.

# Допуски окружения Hive
API_TIMEOUT="${API_TIMEOUT:-120}"

# ---- Константы пакета ----
DIR="$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")"
. "$DIR/h-manifest.conf" 2>/dev/null || true
LOG_FILE="${CUSTOM_LOG_BASENAME}.log"
algo="argon2id"
ver="${CUSTOM_VERSION:-unknown}"

# ---- 1) Парсинг последнего блока [stats] из лога майнера ----
total_hs=0
declare -a hs_list=()
gpu_cnt_log=0

if [[ -f "$LOG_FILE" ]]; then
  start_line="$(grep -n '^\[stats\]' "$LOG_FILE" | tail -n1 | cut -d: -f1 2>/dev/null)"
  if [[ -n "$start_line" ]]; then
    block="$(sed -n "${start_line},\$p" "$LOG_FILE")"
    header="$(head -n1 <<<"$block")"
    total_hs="$(sed -n 's/.*total=\([0-9]\+\)\s*H\/s.*/\1/p' <<<"$header")"
    gpu_cnt_log="$(sed -n 's/.*gpus=\([0-9]\+\).*/\1/p' <<<"$header")"
    while IFS= read -r gl; do
      v="$(sed -n 's/.*\s\([0-9]\+\)\s*H\/s.*/\1/p' <<<"$gl")"
      [[ -n "$v" ]] && hs_list+=("$v")
    done < <(grep -E '^\s*GPU#[0-9]+' <<<"$block" 2>/dev/null)
  fi
fi
[[ -z "$total_hs" ]] && total_hs=0

if (( ${#hs_list[@]} == 0 )); then
  gpu_cnt="$gpu_cnt_log"; (( gpu_cnt < 1 )) && gpu_cnt=1
  base=$(( total_hs / gpu_cnt ))
  rem=$(( total_hs % gpu_cnt ))
  for ((i=0;i<gpu_cnt;i++)); do v=$base; (( i < rem )) && v=$((v+1)); hs_list+=("$v"); done
fi
gpu_cnt="${#hs_list[@]}"

# ---- 2) Сенсоры из $gpu_stats, fallback nvidia-smi ----
declare -a temp_list=()
declare -a fan_list=()
declare -a bus_list=()

if [[ -n "${gpu_stats:-}" ]] && command -v jq >/dev/null 2>&1; then
  mapfile -t temp_list < <(jq -r "[.temp${nvidia_indexes_array:-} // []] | .[]" <<<"$gpu_stats" 2>/dev/null || true)
  mapfile -t fan_list  < <(jq -r "[.fan${nvidia_indexes_array:-}  // []] | .[] | if .==null then 0 else . end" <<<"$gpu_stats" 2>/dev/null || true)
  mapfile -t busids    < <(jq -r ".busids[]?" <<<"$gpu_stats" 2>/dev/null || true)
  for b in "${busids[@]}"; do
    if [[ "$b" =~ ^[0-9A-Fa-f]{8}:([0-9A-Fa-f]{2}): ]]; then
      dom="${BASH_REMATCH[1]}"; bus_list+=( $((16#${dom})) )
    fi
  done
fi

if (( ${#temp_list[@]} == 0 || ${#fan_list[@]} == 0 || ${#bus_list[@]} == 0 )); then
  if command -v nvidia-smi >/dev/null 2>&1; then
    mapfile -t temp_list < <(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null || true)
    while IFS= read -r f; do
      [[ "$f" =~ ^[0-9]+$ ]] && fan_list+=("$f") || fan_list+=(0)
    done < <(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null || true)
    while IFS= read -r b; do
      if [[ "$b" =~ ^[0-9A-Fa-f]{8}:([0-9A-Fa-f]{2}): ]]; then
        dom="${BASH_REMATCH[1]}"; bus_list+=( $((16#${dom})) )
      fi
    done < <(nvidia-smi --query-gpu=pci.bus_id --format=csv,noheader 2>/dev/null || true)
  fi
fi

# ---- 3) Выравнивание длин под gpu_cnt ----
pad_array() { local -n A="$1"; local need="$2";
  if (( ${#A[@]} == 0 )); then for ((i=0;i<need;i++)); do A+=(0); done
  elif (( ${#A[@]} < need )); then local last="${A[-1]}"; for ((i=${#A[@]}; i<need; i++)); do A+=("$last"); done
  elif (( ${#A[@]} > need )); then A=("${A[@]:0:need}")
  fi
}
pad_array temp_list "$gpu_cnt"
pad_array fan_list  "$gpu_cnt"
pad_array bus_list  "$gpu_cnt"

# ---- 4) Uptime ----
pid="$(pgrep -n -f "$CUSTOM_NAME" 2>/dev/null || true)"
uptime=0
[[ -n "$pid" ]] && uptime="$(ps -o etimes= -p "$pid" 2>/dev/null | tr -d ' ' || echo 0)"

# ---- 5) Передача переменных наверх (Hive source) ----
# ВАЖНО: только присваивания, без echo и без exit

# total в kH/s, число
khs="$(awk -v t="$total_hs" 'BEGIN{ printf("%.3f", t/1000.0) }')"

# JSON stats
hs_json="$(printf '%s\n' "${hs_list[@]}" | jq -sc '.')"
temp_json="$(printf '%s\n' "${temp_list[@]}" | jq -sc '.')"
fan_json="$(printf '%s\n' "${fan_list[@]}" | jq -sc '.')"
bus_json="$(printf '%s\n' "${bus_list[@]}" | jq -sc '.')"

stats="$(jq -n \
  --arg algo "$algo" \
  --arg ver  "$ver" \
  --arg     hs_units "hs" \
  --argjson hs   "$hs_json" \
  --argjson temp "$temp_json" \
  --argjson fan  "$fan_json" \
  --argjson bus_numbers "$bus_json" \
  --argjson uptime "$uptime" \
  '{hs:$hs, hs_units:$hs_units, temp:$temp, fan:$fan, algo:$algo, uptime:$uptime, ar:[0,0], bus_numbers:$bus_numbers, ver:$ver }' \
)"
# Конец файла — БЕЗ echo/exit
